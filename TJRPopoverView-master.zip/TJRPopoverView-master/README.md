TJRPopoverView
==============

将IOS中的UIPopoverControl封装为了一个UIView，并在其中放置了一个UITableView用于显示数据
